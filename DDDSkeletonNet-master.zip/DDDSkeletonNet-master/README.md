DDDSkeletonNet
==============

This is a .NET skeleton project to introduce the concepts of Domain Driven Design and loosely coupled layers. 

You can use this solution as a starting point to build loosely coupled and composable applications where the Domain is at the heart of the project.

The current implementation uses Web API as the ultimate consumer but you can easily replace it with any front-end project type you like: console, WPF, MVC, you name it.

I've written a series of blogs around this project. You can follow along here:

http://wp.me/p31q78-pG
