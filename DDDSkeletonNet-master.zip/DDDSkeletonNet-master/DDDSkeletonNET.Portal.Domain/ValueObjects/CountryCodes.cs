﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DDDSkeletonNET.Portal.Domain.ValueObjects
{
	public class CountryCodes
	{
		public readonly static string Germany = "GER";
		public readonly static string Hungary = "HUN";
		public readonly static string Sweden = "SWE";
	}
}
